# Agenda de contactos · React + Tailwind CSS + SQLite

Aplicación web **offline-first** que guarda los contactos en una base SQLite real
compilada a WebAssembly (`sql.js`) que corre dentro del navegador. Se persiste en
`localStorage` y se puede exportar/importar como archivo `.db`.

SENATI · Ingeniería de Software con Inteligencia Artificial · V ciclo
Manual de laboratorio: *Agenda de contactos con React, Tailwind CSS y SQLite*.

## Características

- CRUD completo de contactos con consultas SQL **parametrizadas** (anti inyección).
- Grupos creados por el usuario con clave foránea y `JOIN` (E5).
- Búsqueda, filtro por grupo y **orden configurable resuelto en `ORDER BY`** (E3).
- Campa de cumpleaños guardada como ISO y mostrada en `dd/mm/aaaa` (E1).
- Historial de mensajes de WhatsApp (E6).
- Exportar/importar `agenda.db` con confirmación (E7).
- Panel de estadísticas con `COUNT`, `GROUP BY` y `MIN` (E8).
- Plantillas de mensaje editables con variables `{nombre}`, `{apellido}`, `{telefono}` (E9).
- Botón **Sugerir mensaje** con IA (formal / cercano / breve) (E12).
- Detector de duplicados con distancia de **Levenshtein** y fusión de registros (E11).
- Diálogo de confirmación antes de borrar (E2) y estados vacíos (E4).
- Accesible (foco visible, `aria-label`, diálogos con `aria-modal`) y responsive desde 360 px (E10).

## Requisitos

- Node.js 18 o superior (probado con Node 24).
- Navegador moderno (WebAssembly).

## Instalación y ejecución

```bash
npm install
npm run dev       # entorno de desarrollo
npm run build     # build de producción
npm run preview   # sirve el build
```

## Scripts

| Comando           | Qué hace                                                        |
| ----------------- | ---------------------------------------------------------------- |
| `npm run dev`     | Servidor de desarrollo de Vite.                                  |
| `npm run build`   | Compila a `dist/` (incluye el `sql-wasm.wasm`).                 |
| `npm test`        | Pruebas unitarias (E11) + integración de la capa de datos.       |
| `npm run demo`    | Genera `agenda.db` de ejemplo con 12 contactos (script Node).    |
| `npm run lint`    | Lint con oxlint.                                                 |
| `node scripts/smokeUI.js` | Smoke test de la interfaz con Edge (puppeteer-core).     |

## Estructura

```
src/
  db/
    esquema.js        Esquema SQL (restricciones, FK, índices) y plantillas por defecto
    database.js       Conexión sql.js + persistencia en localStorage (exportar/importar)
    contactosRepo.js  Todo el SQL de contactos (CRUD, listado, duplicados)
    gruposRepo.js     Grupos (E5)
    plantillasRepo.js Plantillas de mensaje (E9)
    estadisticas.js   Estadísticas con COUNT/GROUP BY/MIN (E8)
  utils/
    contacto.js       wa.me, compartir, vCard
    similitud.js      Levenshtein + normalización (E11)
    mensajesIA.js     Sugerir mensaje: LLM configurable + fallback local (E12)
    formatos.js       dd/mm/aaaa y fechas de SQLite (E1, E6)
  hooks/
    useContactos.js   Estado + orquestación del repositorio
    usePlantillas.js  Plantillas
  components/         Formulario, tarjeta, diálogos, estadísticas, plantillas, estados vacíos
scripts/
  crearDemo.js        Genera agenda.db con 12 contactos
  smokeUI.js          Smoke test end-to-end con Edge
```

## Decisiones de diseño

- **Regla de oro**: ningún componente escribe SQL. Los componentes piden datos; el
  repositorio habla con la base. Cambiar SQLite por una API REST solo obliga a
  reescribir el repositorio.
- **Consulta parametrizada**: ningún valor se concatena en la cadena SQL (`?` / `$t`).
  Impide inyección (p. ej. `1; DROP TABLE contactos`) y reutiliza el plan de ejecución.
- **Orden configurable (E3)**: el nombre de una columna no puede viajar como parámetro,
  así que el selector se traduce con una *whitelist* (`ORDENES`) a fragmentos autorizados.
- **Fechas**: `creado_en` y `enviado_en` las pone el motor
  (`datetime('now','localtime')`), no el navegador. El cumpleaños se guarda ISO
  (`2007-03-15`) porque SQLite la ordena bien; solo se formatea al mostrar.
- **Persistencia**: la base vive en memoria; tras cada escritura se ejecuta
  `db.export()` y se guarda en `localStorage` (base64). Al recargar se restaura.
- **Claves foráneas (E5)**: SQLite no las aplica por defecto; se activa
  `PRAGMA foreign_keys = ON` al iniciar.
- **Modelo de lenguaje (E12)**: por defecto funciona con un generador local para que
  el botón no dependa de servicios. Para usar un LLM real, ver la sección siguiente.

## Configurar el modelo de lenguaje (E12)

En la consola del navegador (la config no requiere recargar la app):

```js
localStorage.setItem('agenda_llm_url', 'https://api.openai.com/v1/chat/completions');
localStorage.setItem('agenda_llm_key', 'TU_CLAVE');
```

El prompt pide **únicamente un arreglo JSON** de `{ tono, mensaje }` y la respuesta se
procesa con `JSON.parse` dentro de `try/catch`. Si la URL no está configurada o el
modelo falla, se usa el generador local (formal / cercano / breve).

**Reflexión ética (E12)**: solo se envían al servicio externo los datos mínimos que el
usuario escribió voluntariamente en la ficha (nombre, grupo, notas). No se envían
teléfono, correo ni datos de otros contactos. Conviene evitar notas con información
sensible y avisar al usuario de que esas notas viajan a un tercero.

## Pruebas

- `npm test`: 18 pruebas. Cubren:
  - Levenshtein / similitud normalizada y umbral de 0.85 (E11).
  - Detector de duplicados: "Ana Ríos" vs "Ana Rios" y teléfonos que difieren solo en el prefijo.
  - Capa de datos real (sql.js): CRUD, UNIQUE, FK, orden (whitelist), mensajes MAX(),
    estadísticas, plantillas, exportar/importar.
- `npm run demo`: genera `agenda.db` con 12 contactos (se abre en DB Browser for SQLite).
- `node scripts/smokeUI.js`: abre la app en Edge y comprueba 18 pasos (render, CRUD,
  WhatsApp, E2, E6, E7, E8, E9, E12, accesibilidad básica y ausencia de errores).
- `node scripts/capturaLlena.js`: captura la agenda con los 12 contactos de `agenda.db`.
- `node scripts/capturasVacios.js`: captura los estados vacíos de E4 (agenda sin contactos y búsqueda sin resultados).

## Capturas

![Agenda llena (escritorio)](capturas/agenda-llena.png)
![Agenda llena (móvil)](capturas/agenda-llena-movil.png)
![Agenda vacía (E4)](capturas/estado-agenda-vacia.png)
![Búsqueda sin resultados (E4)](capturas/estado-sin-resultados.png)

Capturas anteriores del smoke test:

![Vista móvil](capturas/demo-movil.png)
![Vista escritorio](capturas/demo-escritorio.png)

## Ejercicios entregados

| #  | Ejercicio                                  | Dónde                                             |
| -- | ------------------------------------------ | ------------------------------------------------- |
| E1 | Campo de cumpleaños (`dd/mm/aaaa`)         | `esquema.js`, `ContactoForm`, `ContactoCard`      |
| E2 | Confirmar antes de borrar                  | `components/DialogoConfirmar.jsx`                 |
| E3 | Orden configurable en `ORDER BY`           | `contactosRepo.js` (`ORDENES` whitelist), `App`   |
| E4 | Estados vacíos                             | `components/EstadosVacios.jsx`                    |
| E5 | Grupos con FK y JOIN                       | `esquema.js`, `gruposRepo.js`, formulario, listado|
| E6 | Historial de mensajes (`MAX(enviado_en)`)  | `esquema.js`, `contactosRepo.js`, `DialogoMensaje`|
| E7 | Copia de seguridad (`Exportar`/`Importar`) | `database.js`, botones en `App.jsx`               |
| E8 | Panel de estadísticas                      | `estadisticas.js`, `PanelEstadisticas.jsx`        |
| E9 | Plantillas de mensaje                      | `plantillasRepo.js`, `PlantillasManager.jsx`      |
| E10| Accesible y responsive                     | `index.css`, componentes con `aria-*` y foco visible |
| E11| Detector de duplicados (Levenshtein)       | `utils/similitud.js`, `contactosRepo.js`, tests   |
| E12| Redacción asistida por modelo              | `utils/mensajesIA.js`, `DialogoMensaje.jsx`       |

## Entregables pendientes (requieren tu cuenta/acción)

1. Repositorio en GitHub: subido en https://github.com/Neptali-Vargas/agenda-contactos
   (`git remote add` / `git push` ya realizados desde la rama `main`).
2. Video de tres minutos demostrando el flujo completo, incluido el envío por WhatsApp.

El informe de **Lighthouse** (E10) ya está generado con **Accesibilidad 95 (≥ 90)** en `lighthouse.html`.
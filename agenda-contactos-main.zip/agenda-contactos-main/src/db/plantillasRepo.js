// E9: repositorio de plantillas de mensaje guardadas en la base.

import { obtenerDB, persistir } from './database.js';

export function listarPlantillas() {
  const res = obtenerDB().exec('SELECT id, nombre, cuerpo FROM plantillas ORDER BY id ASC');
  if (!res.length) return [];
  return res[0].values.map(([id, nombre, cuerpo]) => ({ id, nombre, cuerpo }));
}

export function crearPlantilla(nombre, cuerpo) {
  const db = obtenerDB();
  db.run('INSERT INTO plantillas (nombre, cuerpo) VALUES (?, ?)', [nombre.trim(), cuerpo.trim()]);
  const id = Number(db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0]);
  persistir(); // export() resetea last_insert_rowid: se lee antes
  return id;
}

export function actualizarPlantilla(id, nombre, cuerpo) {
  obtenerDB().run(
    'UPDATE plantillas SET nombre = ?, cuerpo = ? WHERE id = ?',
    [nombre.trim(), cuerpo.trim(), id]
  );
  persistir();
}

export function eliminarPlantilla(id) {
  obtenerDB().run('DELETE FROM plantillas WHERE id = ?', [id]);
  persistir();
}

// Reemplaza las variables {nombre} {apellido} {telefono} del cuerpo.
export function reemplazarVariables(cuerpo, contacto) {
  const mapa = {
    '{nombre}': contacto.nombre ?? '',
    '{apellido}': contacto.apellido ?? '',
    '{telefono}': contacto.telefono ?? ''
  };
  return Object.entries(mapa).reduce(
    (texto, [varible, valor]) => texto.split(varible).join(valor),
    cuerpo
  );
}
import { describe, it, expect, beforeAll } from 'vitest';
import { fileURLToPath } from 'node:url';

// Stub de localStorage para Node
globalThis.localStorage = (() => {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: (k) => m.delete(k)
  };
})();

// El módulo mantiene estado global (db): lo importamos una sola vez.
let base, repo, grupos, plantillas, estadisticas, similitud;
beforeAll(async () => {
  base = await import('./database.js');
  // En Node el import "?url" no produce una ruta accesible: apuntamos al wasm físico.
  const rutaWasm = fileURLToPath(
    new URL('../../node_modules/sql.js/dist/sql-wasm.wasm', import.meta.url)
  );
  base.usarRutaWasm(() => rutaWasm);
  repo = await import('./contactosRepo.js');
  grupos = await import('./gruposRepo.js');
  plantillas = await import('./plantillasRepo.js');
  estadisticas = await import('./estadisticas.js');
  similitud = await import('../utils/similitud.js');
});

describe('capa de datos sobre SQLite real', () => {
  it('inicia la base y siembra plantillas por defecto (E9)', async () => {
    await base.iniciarDB();
    const ps = plantillas.listarPlantillas();
    expect(ps.length).toBeGreaterThanOrEqual(3);
  });

  it('crea, lista y actualiza un contacto (también E1 y E5)', () => {
    grupos.crearGrupo('Trabajo', '#3b82f6');
    const id = repo.crearContacto({
      nombre: 'María', apellido: 'Fernández', telefono: '965 123 456',
      email: 'maria@x.pe', grupo_id: 1, cumple: '1998-07-22',
      favorito: true, notas: 'Demo'
    });
    expect(id).toBeGreaterThan(0);

    let filas = repo.listarContactos({ texto: 'fernández', orden: 'nombre' });
    expect(filas).toHaveLength(1);
    expect(filas[0].grupo_nombre).toBe('Trabajo'); // E5: JOIN resuelto
    expect(filas[0].cumple).toBe('1998-07-22');    // E1
    expect(Number(filas[0].favorito)).toBe(1);

    repo.actualizarContacto(id, {
      nombre: 'María José', apellido: 'Fernández', telefono: '965 123 456',
      email: '', grupo_id: null, cumple: '', favorito: false, notas: ''
    });
    filas = repo.listarContactos({});
    const actualizado = filas.find((f) => f.id === id);
    expect(actualizado.nombre).toBe('María José');
    expect(actualizado.grupo_nombre).toBeNull();
  });

  it('UNIQUE rechaza un teléfono repetido (la base, no React, lo impide)', () => {
    expect(() =>
      repo.crearContacto({
        nombre: 'Copia', apellido: '', telefono: '965 123 456',
        email: '', grupo_id: null, cumple: '', favorito: false, notas: ''
      })
    ).toThrow(/UNIQUE/i);
  });

  it('E3: ordena por criterio distinto sin concatenar entrada del usuario', () => {
    const r = repo.listarContactos({ orden: 'recientes' });
    expect(Array.isArray(r)).toBe(true);
    // un criterio no autorizado cae al orden por defecto (whitelist)
    const r2 = repo.listarContactos({ orden: 'INVALIDO; DROP TABLE contactos' });
    expect(Array.isArray(r2)).toBe(true);
  });

  it('E6: registra mensajes y lista el último con MAX()', () => {
    const id = repo.listarContactos({})[0].id;
    repo.registrarMensaje(id, 'Hola, primer mensaje');
    const filas = repo.listarContactos({});
    expect(filas[0].ultimo_mensaje).toBeTruthy();
  });

  it('E8: estadísticas salen de COUNT / GROUP BY / MIN', () => {
    const s = estadisticas.obtenerEstadisticas();
    expect(s.total).toBeGreaterThan(0);
    expect(Array.isArray(s.porGrupo)).toBe(true);
    expect(s.masAntiguo).toBeTruthy();
  });

  it('E11: el detector une notas escritas "Ana Ríos" / "Ana Rios"', () => {
    repo.crearContacto({
      nombre: 'Ana', apellido: 'Ríos', telefono: '931 887 654',
      email: '', grupo_id: null, cumple: '', favorito: false, notas: ''
    });
    const actuales = repo.listarContactos({});
    const dups = repo.buscarDuplicados(actuales, {
      nombre: 'Ana', apellido: 'Rios', telefono: '999555111'
    });
    expect(dups.some((d) => d.contacto.nombre === 'Ana')).toBe(true);
    expect(similitud.similitud('ana rios', 'ana rios')).toBe(1);
  });

  it('E7: exporta e importa bytes del archivo .db', async () => {
    const bytes = base.exportarBytes();
    expect(bytes.length).toBeGreaterThan(0);
    base.importarBytes(bytes);
    expect(repo.listarContactos({}).length).toBeGreaterThan(0);
  });

  it('E9: reemplaza variables {nombre} en un cuerpo', () => {
    const cuerpo = plantillas.reemplazarVariables(
      'Hola {nombre} {apellido} ({telefono})', { nombre: 'Pep', apellido: 'Tales', telefono: '999' }
    );
    expect(cuerpo).toBe('Hola Pep Tales (999)');
  });
});
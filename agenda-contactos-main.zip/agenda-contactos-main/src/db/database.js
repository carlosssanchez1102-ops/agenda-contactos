import initSqlJs from 'sql.js';
import wasmUrl from 'sql.js/dist/sql-wasm.wasm?url';
import { ESQUEMA, PLANTILLAS_DEFECTO } from './esquema.js';

const CLAVE = 'agenda_contactos_v1';

let SQL = null;   // fábrica de sql.js (necesaria para E7 al importar)
let db = null;

// Dónde está el wasm. En el navegador es la ruta pública que entrega Vite
// (?url); en Node (tests/scripts) se sobrescribe con usarRutaWasm().
let rutaWasm = () => wasmUrl;

export function usarRutaWasm(locate) {
  rutaWasm = locate ? () => locate() : () => wasmUrl;
}

/* Convierte los bytes de la base a texto para poder guardarlos */
const aBase64 = (bytes) => {
  let bin = '';
  const CHUNK = 0x8000; // evita desbordar la pila con bases grandes
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
};

const aBytes = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

export async function iniciarDB() {
  SQL = await initSqlJs({ locateFile: rutaWasm });
  let guardada = null;
  try { guardada = localStorage.getItem(CLAVE); }
  catch (e) { console.warn('Sin acceso a localStorage', e); }

  db = guardada
    ? new SQL.Database(aBytes(guardada))      // base exacta guardada antes
    : new SQL.Database();                     // base nueva y vacía

  db.exec(ESQUEMA);                           // crea tablas solo si no existen

  // E9: sembrar las plantillas por defecto la primera vez
  seedPlantillas();

  persistir();
  return db;
}

export function obtenerDB() {
  if (!db) throw new Error('Llama a iniciarDB() antes de consultar.');
  return db;
}

/* Vuelca la base en localStorage. Se llama tras cada escritura. */
export function persistir() {
  try { localStorage.setItem(CLAVE, aBase64(db.export())); }
  catch (e) { console.warn('No se pudo guardar la base', e); }
}

/* E7: exportar el archivo .db real (el mismo que abre DB Browser for SQLite) */
export function exportarBytes() {
  return obtenerDB().export();
}

/* E7: importar un archivo .db y reemplazar la base actual */
export function importarBytes(bytes) {
  if (!SQL) throw new Error('La base aún no está inicializada.');
  db = new SQL.Database(new Uint8Array(bytes));
  db.exec('PRAGMA foreign_keys = ON;'); // E5: foráneas activas en toda conexión
  persistir();
}

function seedPlantillas() {
  const insert = PLANTILLAS_DEFECTO.map(
    (p) => `INSERT OR IGNORE INTO plantillas (nombre, cuerpo) VALUES (${JSON.stringify(p.nombre)}, ${JSON.stringify(p.cuerpo)})`
  ).join(';\n');
  db.exec(insert);
}
// E8: estadísticas. TODO sale de consultas con COUNT, GROUP BY y MIN/ MAX,
// nunca de recorrer arreglos en JavaScript.

import { obtenerDB } from './database.js';

function consulta(sql, params = []) {
  const res = obtenerDB().exec(sql, params);
  return res.length ? res[0].values : [];
}

export function obtenerEstadisticas() {
  // Total de contactos registrados.
  const total = consulta('SELECT COUNT(*) FROM contactos')[0]?.[0] ?? 0;

  // Cuántos están marcados como favoritos.
  const favoritos = consulta('SELECT COUNT(*) FROM contactos WHERE favorito = 1')[0]?.[0] ?? 0;

  // Mensajes enviados por WhatsApp (E6).
  const mensajes = consulta('SELECT COUNT(*) FROM mensajes')[0]?.[0] ?? 0;

  // Reparto por grupo (GROUP BY + LEFT JOIN para incluir grupos vacíos).
  const porGrupo = consulta(`
    SELECT COALESCE(g.nombre, 'Sin grupo') AS grupo,
           COALESCE(g.color, '#94a3b8')    AS color,
           COUNT(c.id)                     AS total
      FROM grupos g
      LEFT JOIN contactos c ON c.grupo_id = g.id
     GROUP BY g.id
    UNION ALL
    SELECT 'Sin grupo', '#94a3b8', COUNT(*) FROM contactos WHERE grupo_id IS NULL
  `).map(([grupo, color, total]) => ({ grupo, color, total }));

  // Contacto más antiguo (MIN sobre creado_en).
  const masAntiguo = consulta(`
    SELECT nombre || ' ' || apellido AS nombre, creado_en
      FROM contactos
     ORDER BY creado_en ASC, id ASC
     LIMIT 1
  `)[0];

  return { total, favoritos, mensajes, porGrupo, masAntiguo };
}
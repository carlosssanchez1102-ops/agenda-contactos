// Todo el SQL de la aplicación vive aquí. Ningún valor se concatena dentro
// de una cadena: siempre viaja como parámetro (defensa contra inyección SQL).

import { obtenerDB, persistir } from './database.js';
import { normalizarTexto, nombreNormalizado, similitud } from '../utils/similitud.js';
import { normalizarTelefono } from '../utils/contacto.js';

// E3: whitelist de ordenamientos. El nombre de una columna no puede viajar
// como parámetro (?) porque el motor no permite parametrizar identificadores,
// así que cada opción del selector se traduce a un fragmento SQL AUTORIZADO.
export const ORDENES = {
  nombre: 'c.favorito DESC, c.nombre COLLATE NOCASE ASC',
  recientes: 'c.id DESC',
  categoria: 'g.nombre COLLATE NOCASE ASC, c.nombre COLLATE NOCASE ASC'
};
const ORDEN_VALIDO = new Set(Object.keys(ORDENES));

/* ---------- LEER ---------- */
export function listarContactos({ texto = '', grupoId = null, orden = 'nombre' } = {}) {
  // E5: LEFT JOIN con grupos. E6: subconsulta MAX() del último mensaje.
  const sql = `
    SELECT c.*,
           g.nombre AS grupo_nombre,
           g.color  AS grupo_color,
           (SELECT MAX(m.enviado_en)
              FROM mensajes m
             WHERE m.contacto_id = c.id) AS ultimo_mensaje
      FROM contactos c
      LEFT JOIN grupos g ON g.id = c.grupo_id
     WHERE (c.nombre LIKE $t OR c.apellido LIKE $t OR c.telefono LIKE $t)
       AND ($g IS NULL OR c.grupo_id = $g)
     ORDER BY ${ORDENES[orden] && ORDEN_VALIDO.has(orden) ? ORDENES[orden] : ORDENES.nombre}`;
  const stmt = obtenerDB().prepare(sql);
  stmt.bind({ $t: `%${texto}%`, $g: grupoId });
  const filas = [];
  while (stmt.step()) filas.push(stmt.getAsObject());
  stmt.free(); // libera memoria del WASM
  return filas;
}

/* ---------- CREAR ---------- */
export function crearContacto(c) {
  const db = obtenerDB();
  db.run(
    `INSERT INTO contactos (nombre, apellido, telefono, email, grupo_id, cumple, favorito, notas)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      c.nombre.trim(), c.apellido.trim(), c.telefono.trim(),
      c.email?.trim() || null, c.grupo_id ?? null, c.cumple || null,
      c.favorito ? 1 : 0, c.notas?.trim() || ''
    ]
  );
  const id = Number(db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0]);
  persistir(); // export() resetea last_insert_rowid: se lee antes
  return id;
}

/* ---------- ACTUALIZAR ---------- */
export function actualizarContacto(id, c) {
  obtenerDB().run(
    `UPDATE contactos
        SET nombre = ?, apellido = ?, telefono = ?, email = ?,
            grupo_id = ?, cumple = ?, favorito = ?, notas = ?
      WHERE id = ?`,
    [
      c.nombre.trim(), c.apellido.trim(), c.telefono.trim(),
      c.email?.trim() || null, c.grupo_id ?? null, c.cumple || null,
      c.favorito ? 1 : 0, c.notas?.trim() || '', id
    ]
  );
  persistir();
}

/* ---------- ELIMINAR ---------- */
export function eliminarContacto(id) {
  obtenerDB().run('DELETE FROM contactos WHERE id = ?', [id]);
  persistir();
}

/* ---------- FAVORITO ---------- */
export function alternarFavorito(id) {
  obtenerDB().run(
    'UPDATE contactos SET favorito = CASE favorito WHEN 1 THEN 0 ELSE 1 END WHERE id = ?',
    [id]
  );
  persistir();
}

/* ---------- WhatsApp (E6) ---------- */
export function registrarMensaje(contactoId, texto) {
  obtenerDB().run(
    'INSERT INTO mensajes (contacto_id, texto) VALUES (?, ?)',
    [contactoId, texto]
  );
  persistir();
}

/* ---------- ESTADÍSTICAS (E8) ---------- */
export function resumenPorGrupo() {
  const res = obtenerDB().exec(`
    SELECT COALESCE(g.nombre, 'Sin grupo') AS grupo,
           COALESCE(g.color, '#94a3b8')    AS color,
           COUNT(c.id)                     AS total
      FROM contactos c
      LEFT JOIN grupos g ON g.id = c.grupo_id
     GROUP BY COALESCE(g.nombre, 'Sin grupo')
     ORDER BY total DESC`);
  if (!res.length) return [];
  return res[0].values.map(([grupo, color, total]) => ({ grupo, color, total }));
}

/* ---------- E11: detector de duplicados ---------- */
export const UMBRAL_DUPLICADO = 0.85;

export function buscarDuplicados(contactos, candidato, excluirId = null) {
  const nombre = nombreNormalizado(candidato);
  const telefono = normalizarTelefono(candidato.telefono);
  if (!nombre && !telefono) return [];
  return contactos
    .filter((c) => c.id !== excluirId)
    .map((c) => {
      const sNombre = similitud(nombreNormalizado(c), nombre);
      const sTelefono = telefono && normalizarTelefono(c.telefono) === telefono ? 1 : 0;
      const puntaje = Math.max(sNombre, sTelefono);
      return {
        contacto: c,
        puntaje,
        motivo: sTelefono === 1 ? 'mismo teléfono' : 'nombre parecido'
      };
    })
    .filter((d) => d.puntaje >= UMBRAL_DUPLICADO)
    .sort((a, b) => b.puntaje - a.puntaje);
}

/* Parámetros, nunca concatenación
   --------------------------------
   Escribir "... WHERE id = " + id permitiría que alguien envíe
   1; DROP TABLE contactos y borre la agenda completa. Con "?" el motor trata
   ese texto como un valor, jamás como instrucción: es la defensa contra la
   inyección SQL y además SQLite reutiliza el plan de ejecución. */
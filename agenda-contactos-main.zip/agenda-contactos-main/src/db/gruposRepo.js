// E5: repositorio de grupos (sustituye a la columna categoria).

import { obtenerDB, persistir } from './database.js';

export function listarGrupos() {
  const res = obtenerDB().exec('SELECT id, nombre, color FROM grupos ORDER BY nombre COLLATE NOCASE ASC');
  if (!res.length) return [];
  return res[0].values.map(([id, nombre, color]) => ({ id, nombre, color }));
}

export function crearGrupo(nombre, color = '#3b82f6') {
  const db = obtenerDB();
  db.run('INSERT INTO grupos (nombre, color) VALUES (?, ?)', [nombre.trim(), color]);
  const id = Number(db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0]);
  persistir(); // export() resetea last_insert_rowid: se lee antes
  return id;
}

// Devuelve el id existente de un grupo o lo crea (usado por el formulario
// cuando el usuario elige "Crear grupo nuevo…"). UNIQUE lanza si se repite.
export function obtenerOCrearGrupo({ nombre, color }) {
  if (!nombre?.trim()) return null;
  const res = obtenerDB().exec('SELECT id FROM grupos WHERE nombre = ? COLLATE NOCASE', [nombre.trim()]);
  if (res.length && res[0].values.length) return Number(res[0].values[0][0]);
  return crearGrupo(nombre, color);
}
// Esquema completo de la base de datos.
// Se ejecuta con db.exec(ESQUEMA): crea las tablas solo si no existen y
// deja activas las claves foráneas (E5) desde el arranque.

export const ESQUEMA = `
PRAGMA foreign_keys = ON;

-- E5: grupos sustituye a la columna categoria
CREATE TABLE IF NOT EXISTS grupos (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL UNIQUE,
  color  TEXT NOT NULL DEFAULT '#3b82f6'
);

CREATE TABLE IF NOT EXISTS contactos (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre     TEXT NOT NULL,
  apellido   TEXT NOT NULL DEFAULT '',
  telefono   TEXT NOT NULL UNIQUE,
  email      TEXT,
  grupo_id   INTEGER,                                    -- E5: clave foránea
  cumple     TEXT,                                       -- E1: fecha como ISO (2007-03-15)
  favorito   INTEGER NOT NULL DEFAULT 0 CHECK (favorito IN (0, 1)),
  notas      TEXT,
  creado_en  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE SET NULL
);

-- E6: historial de mensajes enviados por WhatsApp
CREATE TABLE IF NOT EXISTS mensajes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  contacto_id INTEGER NOT NULL,
  texto       TEXT NOT NULL DEFAULT '',
  enviado_en  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (contacto_id) REFERENCES contactos(id) ON DELETE CASCADE
);

-- E9: plantillas de mensaje guardadas en la base
CREATE TABLE IF NOT EXISTS plantillas (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL UNIQUE,
  cuerpo TEXT NOT NULL
);

-- Acelera las búsquedas por nombre cuando la agenda crece
CREATE INDEX IF NOT EXISTS idx_contactos_nombre ON contactos(nombre);
CREATE INDEX IF NOT EXISTS idx_contactos_grupo  ON contactos(grupo_id);
CREATE INDEX IF NOT EXISTS idx_mensajes_contacto ON mensajes(contacto_id);
`;

// E9: plantillas que se siembran la primera vez
export const PLANTILLAS_DEFECTO = [
  {
    nombre: 'Saludo',
    cuerpo: 'Hola {nombre}, ¿cómo estás? Te escribo desde mi agenda de contactos. ¡Saludos!'
  },
  {
    nombre: 'Recordatorio de reunión',
    cuerpo: 'Hola {nombre}, te recuerdo nuestra reunión. Avísame si te queda bien. ¡Gracias!'
  },
  {
    nombre: 'Cobranza',
    cuerpo: 'Hola {nombre}, te recuerdo que tienes un pago pendiente. Por favor coordina el abono. Gracias.'
  }
];
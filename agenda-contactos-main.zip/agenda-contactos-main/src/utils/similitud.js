// E11: distancia de Levenshtein y similitud normalizada para detectar duplicados.

export function distanciaLevenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;

  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      const costo = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(
        cur[j - 1] + 1,      // inserción
        prev[j] + 1,         // borrado
        prev[j - 1] + costo  // sustitución
      );
    }
    prev = cur;
  }
  return prev[n];
}

// Similitud normalizada: 1 = idénticos, 0 = totalmente distintos.
// Umbral justificado en E11: 0.85 sobre texto normalizado suele ser correcto.
export function similitud(a, b) {
  if (a === b) return 1;
  const maxLargo = Math.max(a.length, b.length);
  if (maxLargo === 0) return 1;
  return 1 - distanciaLevenshtein(a, b) / maxLargo;
}

// Normaliza para comparar: minúsculas y sin tildes.
export function normalizarTexto(texto) {
  return String(texto ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// Nombre completo estandarizado para comparar: "carlos garcia"
export function nombreNormalizado(c) {
  return normalizarTexto(`${c.nombre} ${c.apellido}`);
}
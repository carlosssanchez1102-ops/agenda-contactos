const PREFIJO_PAIS = '51'; // Perú

/* '+51 965 123 456' -> '51965123456' */
export function normalizarTelefono(telefono) {
  const digitos = String(telefono || '').replace(/\D/g, '');
  if (digitos.startsWith(PREFIJO_PAIS)) return digitos;
  return PREFIJO_PAIS + digitos.replace(/^0+/, '');
}

/* Enlace listo para abrir el chat con el mensaje escrito */
export function enlaceWhatsApp(telefono, mensaje = '') {
  const numero = normalizarTelefono(telefono);
  const texto = encodeURIComponent(mensaje);
  return `https://wa.me/${numero}${texto ? `?text=${texto}` : ''}`;
}

/* Compartir con el sistema operativo; si no existe, copia al portapapeles */
export async function compartirContacto(c) {
  const texto =
    `${c.nombre} ${c.apellido}\n` +
    `Teléfono: +${normalizarTelefono(c.telefono)}\n` +
    (c.email ? `Correo: ${c.email}\n` : '');
  if (navigator.share) {
    try {
      await navigator.share({ title: c.nombre, text: texto });
      return 'compartido';
    } catch (e) {
      if (e.name === 'AbortError') return 'cancelado';
    }
  }
  await navigator.clipboard.writeText(texto);
  return 'copiado';
}

/* Descarga el contacto como archivo .vcf que reconoce cualquier agenda */
export function descargarVCard(c) {
  const vcf = [
    'BEGIN:VCARD', 'VERSION:3.0',
    `N:${c.apellido};${c.nombre};;;`,
    `FN:${c.nombre} ${c.apellido}`,
    `TEL;TYPE=CELL:+${normalizarTelefono(c.telefono)}`,
    c.email ? `EMAIL:${c.email}` : null,
    `NOTE:${c.notas ?? ''}`,
    'END:VCARD'
  ].filter(Boolean).join('\r\n'); // CRLF: sin él, varias agendas de Android ignoran el archivo

  const url = URL.createObjectURL(new Blob([vcf], { type: 'text/vcard' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `${c.nombre}-${c.apellido}.vcf`;
  a.click();
  URL.revokeObjectURL(url);
}

/* Justificación de "Nada de + ni 00 en wa.me": el enlace solo acepta dígitos. */
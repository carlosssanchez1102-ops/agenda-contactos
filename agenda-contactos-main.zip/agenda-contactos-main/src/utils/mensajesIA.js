// E12: redacción asistida por modelo de lenguaje.
// Si se configura una URL OpenAI-compatible se consulta el modelo real y se
// procesa su respuesta (JSON.parse envuelto en try/catch); si no hay
// configuración o el modelo falla, se usa un generador local.

const CLAVE_URL = 'agenda_llm_url';
const CLAVE_KEY = 'agenda_llm_key';

export const TONOS = ['formal', 'cercano', 'breve'];

export function configurarLLM(url, key = '') {
  try {
    if (url) localStorage.setItem(CLAVE_URL, url);
    else localStorage.removeItem(CLAVE_URL);
    if (key) localStorage.setItem(CLAVE_KEY, key);
    else localStorage.removeItem(CLAVE_KEY);
  } catch (e) {
    console.warn('No se pudo guardar la configuración del modelo', e);
  }
}

function configLLM() {
  if (typeof localStorage === 'undefined') return { url: '', key: '' };
  return { url: localStorage.getItem(CLAVE_URL) || '', key: localStorage.getItem(CLAVE_KEY) || '' };
}

// Llama al modelo pidiendo SOLO un arreglo JSON de { tono, mensaje }.
async function llamarModelo(prompt) {
  const { url, key } = configLLM();
  const respuesta = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(key ? { Authorization: `Bearer ${key}` } : {})
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }]
    })
  });
  if (!respuesta.ok) throw new Error(`El modelo respondió ${respuesta.status}`);
  const datos = await respuesta.json();
  const contenido = datos.choices?.[0]?.message?.content;
  if (!contenido) throw new Error('El modelo no devolvió contenido.');
  return JSON.parse(contenido); // puede lanzar -> lo atrapa quien llama
}

const sanitizar = (s) => String(s ?? '').replace(/\s+/g, ' ').trim();

// Fallback local: tres tonos distintos sin depender de un servicio externo.
function generarLocal(c) {
  const nombre = sanitizar(`${c.nombre} ${c.apellido}`) || 'amigo/a';
  const grupo = sanitizar(c.grupo_nombre) || 'mi agenda';
  const notas = sanitizar(c.notas);
  const contexto = notas ? ` Tengo anotado: "${notas}".` : '';
  return [
    {
      tono: 'formal',
      mensaje: `Estimado/a ${nombre}${contexto} Le escribo desde ${grupo} para ponerme en contacto con usted. Quedo atento/a a su respuesta.`
    },
    {
      tono: 'cercano',
      mensaje: `¡Hola ${nombre}!${contexto} Soy de ${grupo} y quería saludarte y saber cómo estás. ¡Escríbeme cuando puedas!`
    },
    {
      tono: 'breve',
      mensaje: `Hola ${nombre}, te escribo de ${grupo}.${contexto} Cualquier cosa me avisas.`
    }
  ];
}

// Devuelve siempre tres propuestas { tono, mensaje }.
export async function sugerirMensajes(contacto) {
  const { url } = configLLM();
  if (url) {
    const contactoPreparado = {
      nombre: sanitizar(contacto.nombre),
      apellido: sanitizar(contacto.apellido),
      grupo: sanitizar(contacto.grupo_nombre),
      notas: sanitizar(contacto.notas)
    };
    const prompt =
      'Eres un asistente de redacción de WhatsApp. Con estos datos de contacto: ' +
      JSON.stringify(contactoPreparado) +
      ', escribe el mensaje inicial para presentarse o retomar el contacto. ' +
      'Responde ÚNICAMENTE con un arreglo JSON de tres objetos con la forma ' +
      '{"tono":"formal|cercano|breve", "mensaje":"..."}, sin texto adicional, sin markdown.';
    const propuestas = await llamarModelo(prompt); // puede lanzar
    if (Array.isArray(propuestas) && propuestas.length >= 1) {
      return propuestas.slice(0, 3).map((p, i) => ({
        tono: p.tono || TONOS[i] || 'cercano',
        mensaje: sanitizar(p.mensaje) || generarLocal(contacto)[i]?.mensaje
      }));
    }
    throw new Error('El modelo no devolvió un arreglo válido.');
  }
  return generarLocal(contacto);
}

/* Reflexión (E12): solo se envían al servicio externo los datos mínimos que
   el usuario escribió voluntariamente en la ficha (nombre, grupo, notas). No
   se envían teléfono, correo ni datos de otros contactos. El usuario debe
   saber que esas notas viajan a un tercero y evitarlo con datos sensibles. */
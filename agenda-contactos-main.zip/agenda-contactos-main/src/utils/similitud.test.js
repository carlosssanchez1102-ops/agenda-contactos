import { describe, it, expect } from 'vitest';
import { distanciaLevenshtein, similitud, normalizarTexto, nombreNormalizado } from './similitud.js';
import { buscarDuplicados, UMBRAL_DUPLICADO } from '../db/contactosRepo.js';
import { normalizarTelefono } from './contacto.js';

describe('distanciaLevenshtein', () => {
  it('devuelve 0 para cadenas idénticas', () => {
    expect(distanciaLevenshtein('asdfgh', 'asdfgh')).toBe(0);
  });

  it('cuenta inserciones, borrados y sustituciones', () => {
    expect(distanciaLevenshtein('kitten', 'sitting')).toBe(3);
    expect(distanciaLevenshtein('', 'abc')).toBe(3);
    expect(distanciaLevenshtein('abc', '')).toBe(3);
  });
});

describe('similitud', () => {
  it('es 1 para textos iguales y 0 para totalmente distintos', () => {
    expect(similitud('ana rios', 'ana rios')).toBe(1);
    expect(similitud('ana rios', 'zzzzzzzz')).toBeLessThan(0.4);
  });

  it('"Ana Ríos" frente a "Ana Rios" supera el umbral justificado de 0.85', () => {
    const s = similitud(normalizarTexto('Ana Ríos'), normalizarTexto('Ana Rios'));
    expect(s).toBeGreaterThanOrEqual(UMBRAL_DUPLICADO);
  });
});

describe('normalizarTexto', () => {
  it('pasa a minúsculas y quita tildes', () => {
    expect(normalizarTexto('ÁNa Ríos')).toBe('ana rios');
  });
});

describe('nombreNormalizado', () => {
  it('compone nombre + apellido', () => {
    expect(nombreNormalizado({ nombre: 'Ana', apellido: 'Ríos' })).toBe('ana rios');
  });
});

describe('buscarDuplicados (E11)', () => {
  const contactos = [
    { id: 1, nombre: 'Ana', apellido: 'Ríos', telefono: '+51 931 887 654' }
  ];

  it('detecta parecido por nombre con y sin tildes', () => {
    const dups = buscarDuplicados(contactos, { nombre: 'Ana', apellido: 'Rios', telefono: '999999999' });
    expect(dups).toHaveLength(1);
    expect(dups[0].contacto.id).toBe(1);
    expect(dups[0].motivo).toBe('nombre parecido');
  });

  it('detecta dos teléfonos que solo difieren en el prefijo', () => {
    const c1 = { id: 2, nombre: 'Ana', apellido: 'Ríos', telefono: '931 887 654' };       // -> 51931887654
    const candidato = { nombre: 'Ana', apellido: 'Ríos', telefono: '+51931 887 654' };    // -> 51931887654
    expect(normalizarTelefono(c1.telefono)).toBe(normalizarTelefono(candidato.telefono));
    const dups = buscarDuplicados([c1], candidato);
    expect(dups).toHaveLength(1);
    expect(dups[0].motivo).toBe('mismo teléfono');
  });

  it('no se marca a sí mismo durante la edición (excluirId)', () => {
    const dups = buscarDuplicados(contactos, { nombre: 'Ana', apellido: 'Ríos', telefono: '999999999' }, 1);
    expect(dups).toHaveLength(0);
  });
});
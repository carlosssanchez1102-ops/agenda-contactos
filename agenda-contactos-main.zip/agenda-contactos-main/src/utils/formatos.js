// E1: la fecha se guarda como texto ISO (2007-03-15) porque SQLite la ordena
// correctamente; solo al mostrar se convierte al formato peruano dd/mm/aaaa.
export function formatearFechaISO(iso) {
  if (!iso) return '';
  const [anio, mes, dia] = iso.split('T')[0].split('-');
  if (!anio || !mes || !dia) return iso;
  return `${dia}/${mes}/${anio}`;
}

// E6: "YYYY-MM-DD HH:MM:SS" (datetime de SQLite) -> "dd/mm/aaaa hh:mm"
export function formatearFechaHora(dt) {
  if (!dt) return '';
  const [fecha, hora] = String(dt).split(' ');
  const dia = formatearFechaISO(fecha);
  if (!hora) return dia;
  const [hh, mm] = hora.split(':');
  return `${dia} ${hh}:${mm}`;
}
import { useState, useEffect } from 'react';
import Modal from './Modal.jsx';
import { obtenerEstadisticas } from '../db/estadisticas.js';
import { formatearFechaHora } from '../utils/formatos.js';

// E8: el panel solo muestra lo que devuelven consultas COUNT / GROUP BY / MIN.
export default function PanelEstadisticas({ onCerrar }) {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    setStats(obtenerEstadisticas());
  }, []);

  const maxTotal = Math.max(1, ...(stats?.porGrupo.map((g) => g.total) ?? [1]));

  return (
    <Modal titulo="Estadísticas (E8)" onCerrar={onCerrar}>
      {!stats ? (
        <p className="text-sm text-slate-500">Cargando…</p>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-lg bg-blue-50 p-3 text-center">
            <p className="text-2xl font-bold text-blue-700">{stats.total}</p>
            <p className="text-xs text-slate-500">Contactos</p>
          </div>
          <div className="rounded-lg bg-amber-50 p-3 text-center">
            <p className="text-2xl font-bold text-amber-600">{stats.favoritos}</p>
            <p className="text-xs text-slate-500">Favoritos</p>
          </div>
          <div className="rounded-lg bg-green-50 p-3 text-center">
            <p className="text-2xl font-bold text-green-600">{stats.mensajes}</p>
            <p className="text-xs text-slate-500">Mensajes enviados</p>
          </div>

          <div className="sm:col-span-2 rounded-lg border p-3">
            <p className="mb-2 text-xs font-medium text-slate-600">Reparto por grupo</p>
            <ul className="space-y-2">
              {stats.porGrupo.map((g) => (
                <li key={g.grupo} className="text-sm">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: g.color }} aria-hidden="true" />
                    <span className="min-w-0 truncate">{g.grupo}</span>
                    <span className="ml-auto font-medium">{g.total}</span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded bg-slate-100">
                    <div className="h-full rounded bg-blue-500" style={{ width: `${(g.total / maxTotal) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border p-3">
            <p className="mb-2 text-xs font-medium text-slate-600">Contacto más antiguo</p>
            {stats.masAntiguo ? (
              <>
                <p className="truncate text-sm font-medium">{stats.masAntiguo[0]}</p>
                <p className="text-xs text-slate-500">{formatearFechaHora(stats.masAntiguo[1])}</p>
              </>
            ) : (
              <p className="text-sm text-slate-400">Sin contactos</p>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
}
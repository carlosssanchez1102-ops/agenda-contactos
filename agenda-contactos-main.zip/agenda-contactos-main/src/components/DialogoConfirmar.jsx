import { useEffect, useRef } from 'react';

// E2: diálogo de confirmación reutilizable. Prohibido window.confirm:
// el cierre, el foco y los mensajes se controlan desde React.
export default function DialogoConfirmar({
  abierto = false,
  titulo = '¿Confirmar?',
  mensaje = '',
  onAceptar,
  onCancelar,
  aceptarTexto = 'Confirmar'
}) {
  const refAceptar = useRef(null);

  useEffect(() => {
    if (!abierto) return;
    refAceptar.current?.focus();
    const alTecla = (e) => {
      if (e.key === 'Escape') onCancelar();
    };
    window.addEventListener('keydown', alTecla);
    return () => window.removeEventListener('keydown', alTecla);
  }, [abierto, onCancelar]);

  if (!abierto) return null;

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-slate-900/40 p-4"
      onClick={onCancelar}
    >
      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="confirmar-titulo"
        aria-describedby="confirmar-mensaje"
        className="w-full max-w-sm rounded-xl bg-white p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="confirmar-titulo" className="text-base font-semibold">{titulo}</h2>
        <p id="confirmar-mensaje" className="mt-2 text-sm text-slate-600">{mensaje}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button
            onClick={onCancelar}
            className="rounded-lg border px-4 py-2 text-sm hover:bg-slate-100"
          >
            Cancelar
          </button>
          <button
            ref={refAceptar}
            onClick={onAceptar}
            className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
          >
            {aceptarTexto}
          </button>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import Modal from './Modal.jsx';
import { sugerirMensajes } from '../utils/mensajesIA.js';
import { reemplazarVariables } from '../db/plantillasRepo.js';

// E9 + E12: elige plantilla, edita a mano o pide sugerencias al modelo.
// Recién entonces se abre WhatsApp (el envío real lo hace App con onEnviar).
export default function DialogoMensaje({ contacto, plantillas, onCerrar, onEnviar }) {
  const [texto, setTexto] = useState(() => {
    const saludo = plantillas.find((p) => p.nombre === 'Saludo');
    return saludo ? reemplazarVariables(saludo.cuerpo, contacto) : `Hola ${contacto.nombre}, te escribo desde mi agenda de contactos.`;
  });
  const [proponiendo, setProponiendo] = useState(false);
  const [propuestas, setPropuestas] = useState([]);
  const [error, setError] = useState('');

  const usarPlantilla = (p) => setTexto(reemplazarVariables(p.cuerpo, contacto));

  // E12: tres tonos (formal, cercano, breve) con estado de carga y de error
  const sugerir = async () => {
    setProponiendo(true);
    setError('');
    try {
      const resultado = await sugerirMensajes(contacto);
      setPropuestas(resultado);
    } catch (e) {
      setError('No se pudieron generar sugerencias: ' + e.message);
    } finally {
      setProponiendo(false);
    }
  };

  return (
    <Modal titulo={`Mensaje para ${contacto.nombre}`} onCerrar={onCerrar} ancho="max-w-xl">
      <div className="space-y-3">
        <div>
          <p className="mb-1 text-xs font-medium text-slate-600">Plantillas (E9)</p>
          <div className="flex flex-wrap gap-2">
            {plantillas.map((p) => (
              <button
                key={p.id}
                onClick={() => usarPlantilla(p)}
                className="rounded-full border px-3 py-1 text-xs hover:bg-slate-100"
              >
                {p.nombre}
              </button>
            ))}
          </div>
          <p className="mt-1 text-xs text-slate-400">Variables: {'{nombre}'} {'{apellido}'} {'{telefono}'}</p>
        </div>

        <label className="block text-xs font-medium text-slate-600">
          Mensaje
          <textarea
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            rows={4}
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
          />
        </label>

        <button
          onClick={sugerir}
          disabled={proponiendo}
          className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-50 disabled:opacity-50"
        >
          {proponiendo ? 'Generando…' : '✨ Sugerir mensaje (E12)'}
        </button>

        {error && <p role="alert" className="text-xs text-red-600">{error}</p>}

        {propuestas.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-slate-600">Propuestas del modelo</p>
            {propuestas.map((p, i) => (
              <button
                key={i}
                onClick={() => setTexto(p.mensaje)}
                className="block w-full rounded-lg border border-slate-200 p-3 text-left text-sm hover:bg-slate-50"
              >
                <span className="text-xs font-medium uppercase text-slate-400">{p.tono}</span>
                <span className="block">{p.mensaje}</span>
              </button>
            ))}
          </div>
        )}

        <div className="flex justify-end gap-2 pt-1">
          <button onClick={onCerrar} className="rounded-lg border px-4 py-2 text-sm hover:bg-slate-100">
            Cancelar
          </button>
          <button
            onClick={() => onEnviar(texto)}
            className="rounded-lg bg-whatsapp px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Abrir WhatsApp
          </button>
        </div>
      </div>
    </Modal>
  );
}
import { useEffect, useRef } from 'react';

// Base accesible para diálogos (E10): se cierra con Escape, foco al abrir y
// aria-modal. No es un foco-trampa completo pero cubre el flujo con teclado.
export default function Modal({ titulo, onCerrar, children, ancho = 'max-w-lg' }) {
  const refCerrar = useRef(null);

  useEffect(() => {
    refCerrar.current?.focus?.();
    const alTecla = (e) => {
      if (e.key === 'Escape') onCerrar();
    };
    window.addEventListener('keydown', alTecla);
    return () => window.removeEventListener('keydown', alTecla);
  }, [onCerrar]);

  return (
    <div
      className="fixed inset-0 z-40 grid place-items-center overflow-y-auto bg-slate-900/40 p-4"
      onClick={onCerrar}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={titulo}
        className={`w-full ${ancho} rounded-xl bg-white p-5 shadow-xl`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <h2 className="text-base font-semibold">{titulo}</h2>
          <button
            ref={refCerrar}
            onClick={onCerrar}
            aria-label="Cerrar ventana"
            className="rounded-lg border px-2 py-0.5 text-sm hover:bg-slate-100"
          >
            ✕
          </button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}
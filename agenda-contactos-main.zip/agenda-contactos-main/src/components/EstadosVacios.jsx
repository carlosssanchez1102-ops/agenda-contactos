// E4: dos estados vacíos distintos, cada uno con su mensaje y una acción.
export function AgendaVacia({ onAgregar }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center">
      <p className="text-sm font-medium text-slate-600">Tu agenda está vacía</p>
      <p className="mt-1 text-sm text-slate-400">
        Agrega tu primer contacto para empezar a guardar teléfonos, correos y notas.
      </p>
      <button
        onClick={onAgregar}
        className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
      >
        Agregar primer contacto
      </button>
    </div>
  );
}

export function SinResultados({ onLimpiar }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center">
      <p className="text-sm font-medium text-slate-600">Sin resultados</p>
      <p className="mt-1 text-sm text-slate-400">
        Ningún contacto coincide con la búsqueda o el grupo elegido.
      </p>
      <button
        onClick={onLimpiar}
        className="mt-4 rounded-lg border px-4 py-2 text-sm hover:bg-slate-100"
      >
        Limpiar filtros
      </button>
    </div>
  );
}
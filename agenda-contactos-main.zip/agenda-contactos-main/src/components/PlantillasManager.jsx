import { useState } from 'react';
import Modal from './Modal.jsx';

// E9: administrar las plantillas guardadas en la base.
// Las variables permitidas son {nombre} {apellido} {telefono}.
export default function PlantillasManager({ plantillas, onCerrar, onGuardar, onCrear, onEliminar }) {
  const [error, setError] = useState('');
  const [nueva, setNueva] = useState(false);

  const input = 'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';

  // Cada fila guarda sus ediciones locales
  const filas = plantillas.map((p) => <PlantillaRow key={p.id} plantilla={p} input={input}
    onGuardar={(nombre, cuerpo) => {
      if (onGuardar(p.id, nombre, cuerpo)) {
        setError('');
      } else setError('No se pudo guardar (¿el nombre ya existe?).');
    }}
    onEliminar={() => onEliminar(p.id)}
  />);

  return (
    <Modal titulo="Plantillas de mensaje (E9)" onCerrar={onCerrar} ancho="max-w-xl">
      {error && <p role="alert" className="mb-2 text-xs text-red-600">{error}</p>}
      <div className="space-y-3">
        {filas}
        {nueva && (
          <PlantillaRow
            plantilla={{ id: null, nombre: '', cuerpo: '' }}
            input={input}
            onGuardar={(nombre, cuerpo) => {
              if (onCrear(nombre, cuerpo)) {
                setNueva(false); setError('');
              } else setError('No se pudo crear (¿el nombre ya existe?).');
            }}
          />
        )}
        {!nueva && (
          <button
            onClick={() => setNueva(true)}
            className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-50"
          >
            + Nueva plantilla
          </button>
        )}
        <p className="text-xs text-slate-500">
          Variables disponibles: {'{nombre}'} {'{apellido}'} {'{telefono}'}.
        </p>
        {plantillas.length === 0 && !nueva && (
          <p className="text-sm text-slate-400">No hay plantillas todavía.</p>
        )}
      </div>
    </Modal>
  );
}

function PlantillaRow({ plantilla, input, onGuardar, onEliminar }) {
  const [nombre, setNombre] = useState(plantilla.nombre);
  const [cuerpo, setCuerpo] = useState(plantilla.cuerpo);
  const esEditable = !!plantilla.id;

  return (
    <div className="rounded-lg border p-3">
      <input
        className={input}
        aria-label="Nombre de la plantilla"
        placeholder="Nombre"
        value={nombre}
        onChange={(e) => setNombre(e.target.value)}
      />
      <textarea
        className={input + ' mt-2'}
        rows={3}
        aria-label="Cuerpo de la plantilla"
        placeholder="Hola {nombre}, ..."
        value={cuerpo}
        onChange={(e) => setCuerpo(e.target.value)}
      />
      <div className="mt-2 flex gap-2">
        <button
          onClick={() => onGuardar(nombre, cuerpo)}
          className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700"
        >
          {esEditable ? 'Guardar cambios' : 'Crear plantilla'}
        </button>
        {esEditable && (
          <button
            onClick={onEliminar}
            aria-label={`Eliminar plantilla ${nombre}`}
            className="rounded-lg border border-red-200 px-3 py-1.5 text-xs text-red-600 hover:bg-red-50"
          >
            Eliminar
          </button>
        )}
      </div>
    </div>
  );
}
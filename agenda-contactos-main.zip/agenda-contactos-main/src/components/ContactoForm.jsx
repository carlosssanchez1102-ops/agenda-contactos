import { useState, useEffect, useRef } from 'react';
import { buscarDuplicados } from '../db/contactosRepo.js';

const VACIO = {
  nombre: '',
  apellido: '',
  telefono: '',
  email: '',
  cumple: '',          // E1: guardado como ISO (input type="date")
  grupo_id: null,      // E5: id de grupo o null ("Sin grupo")
  grupoNuevo: null,    // E5: { nombre, color } cuando se crea en el formulario
  favorito: false,
  notas: ''
};

const PALETA = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#14b8a6'];

export default function ContactoForm({ grupos, contactos = [], editando, onGuardar, onFusionar, onCancelar, onEliminarError }) {
  const [form, setForm] = useState(VACIO);
  const [fallos, setFallos] = useState({});
  const [dups, setDups] = useState([]);       // E11
  const conDupesRef = useRef(false);          // se lee en enviar() sin esperar el estado

  useEffect(() => {
    setForm(
      editando
        ? { ...VACIO, ...editando, favorito: !!editando.favorito }
        : VACIO
    );
    setFallos({});
    setDups([]);
    conDupesRef.current = false;
    onEliminarError?.();
  }, [editando, onEliminarError]);

  const cambiar = (campo) => (e) =>
    setForm({
      ...form,
      [campo]: e.target.type === 'checkbox' ? e.target.checked : e.target.value
    });

  const validar = () => {
    const f = {};
    if (!form.nombre.trim()) f.nombre = 'Escribe el nombre';
    if (!/^[0-9+\s]{6,15}$/.test(form.telefono)) f.telefono = 'Teléfono no válido';
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) f.email = 'Correo no válido';
    if (form.grupo_id === '__nuevo__' && !form.grupoNuevo?.nombre?.trim()) {
      f.grupoNuevo = 'Escribe el nombre del grupo';
    }
    setFallos(f);
    return Object.keys(f).length === 0;
  };

  const recoger = () => {
    if (form.grupo_id === '__nuevo__') {
      return {
        ...form,
        grupo_id: null,
        grupoNuevo: { nombre: form.grupoNuevo.nombre, color: form.grupoNuevo.color }
      };
    }
    return { ...form, grupoNuevo: null };
  };

  const guardar = async () => {
    const ok = await onGuardar(recoger());
    if (ok) {
      setForm(VACIO);
      setDups([]);
      conDupesRef.current = false;
    }
  };

  const enviar = async () => {
    if (!validar()) return;
    // E11: avisar antes de duplicar "Ana Ríos" con "Ana Rios"
    const encontrados = buscarDuplicados(contactos, recoger(), editando?.id ?? null);
    if (encontrados.length && !conDupesRef.current) {
      setDups(encontrados);
      return;
    }
    await guardar();
  };

  // "Agregar de todos modos": marca la ref y reintenta sin bloqueo
  const aceptarDuplicados = () => {
    conDupesRef.current = true;
    setDups([]);
    enviar();
  };

  const fusionar = async () => {
    const ok = await onFusionar(dups[0].contacto.id, recoger());
    if (ok) {
      setForm(VACIO);
      setDups([]);
      conDupesRef.current = false;
    }
  };

  const input =
    'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm ' +
    'focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';

  const elegirGrupo = (e) => {
    const valor = e.target.value;
    setForm({
      ...form,
      grupo_id: valor === '' ? null : valor === '__nuevo__' ? '__nuevo__' : Number(valor)
    });
  };

  return (
    <div className="space-y-3 rounded-xl bg-white p-4 shadow-sm">
      <h2 className="text-base font-semibold">
        {editando ? 'Editar contacto' : 'Nuevo contacto'}
      </h2>

      {dups.length > 0 && (
        <div role="alert" className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <p className="font-medium">Posible contacto duplicado</p>
          {dups.map((d) => (
            <p key={d.contacto.id} className="mt-1">
              «{d.contacto.nombre} {d.contacto.apellido}» se parece al que estás
              escribiendo ({Math.round(d.puntaje * 100)} %, {d.motivo}).
            </p>
          ))}
          <div className="mt-2 flex flex-wrap gap-2">
            <button
              onClick={aceptarDuplicados}
              className="rounded-lg border border-amber-400 px-3 py-1 text-xs hover:bg-amber-100"
            >
              Agregar de todos modos
            </button>
            <button
              onClick={fusionar}
              className="rounded-lg bg-amber-500 px-3 py-1 text-xs font-medium text-white hover:bg-amber-600"
            >
              Fusionar registros
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <input
            className={input}
            id="campo-nombre"
            placeholder="Nombre *"
            aria-label="Nombre"
            value={form.nombre}
            onChange={cambiar('nombre')}
          />
          {fallos.nombre && <p className="mt-1 text-xs text-red-600">{fallos.nombre}</p>}
        </div>
        <input className={input} placeholder="Apellido" aria-label="Apellido"
          value={form.apellido} onChange={cambiar('apellido')} />
        <div>
          <input
            className={input}
            placeholder="Teléfono: 965123456 *"
            aria-label="Teléfono"
            inputMode="tel"
            value={form.telefono}
            onChange={cambiar('telefono')}
          />
          {fallos.telefono && <p className="mt-1 text-xs text-red-600">{fallos.telefono}</p>}
        </div>
        <div>
          <input className={input} placeholder="Correo" aria-label="Correo" type="email"
            value={form.email} onChange={cambiar('email')} />
          {fallos.email && <p className="mt-1 text-xs text-red-600">{fallos.email}</p>}
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-600">
            Cumpleaños (E1)
            <input className={input + ' mt-1'} type="date" aria-label="Cumpleaños"
              value={form.cumple} onChange={cambiar('cumple')} />
          </label>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-600">
            Grupo (E5)
            <select className={input + ' mt-1'} aria-label="Grupo" value={form.grupo_id ?? ''}
              onChange={elegirGrupo}>
              <option value="">Sin grupo</option>
              {grupos.map((g) => (
                <option key={g.id} value={g.id}>{g.nombre}</option>
              ))}
              <option value="__nuevo__">+ Crear grupo nuevo…</option>
            </select>
          </label>
          {form.grupo_id === '__nuevo__' && (
            <div className="mt-2 flex items-center gap-2">
              <input
                className={input}
                placeholder="Nombre del grupo"
                aria-label="Nombre del grupo nuevo"
                value={form.grupoNuevo?.nombre ?? ''}
                onChange={(e) => setForm({ ...form, grupoNuevo: { ...form.grupoNuevo, nombre: e.target.value } })}
              />
              <input
                type="color"
                aria-label="Color del grupo"
                className="h-9 w-12 shrink-0 cursor-pointer rounded border border-slate-300"
                value={form.grupoNuevo?.color ?? PALETA[0]}
                onChange={(e) => setForm({ ...form, grupoNuevo: { ...form.grupoNuevo, color: e.target.value } })}
              />
            </div>
          )}
          {fallos.grupoNuevo && <p className="mt-1 text-xs text-red-600">{fallos.grupoNuevo}</p>}
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={form.favorito} onChange={cambiar('favorito')} />
          Marcar como favorito
        </label>
        <textarea className={input} rows={2} placeholder="Notas"
          aria-label="Notas" value={form.notas} onChange={cambiar('notas')} />
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={enviar}
          className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
        >
          {editando ? 'Guardar cambios' : 'Agregar contacto'}
        </button>
        <button onClick={onCancelar}
          className="rounded-lg border px-4 py-2 text-sm hover:bg-slate-100">
          Cancelar
        </button>
      </div>
    </div>
  );
}
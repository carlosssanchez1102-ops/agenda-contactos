import { compartirContacto, descargarVCard } from '../utils/contacto.js';
import { formatearFechaISO, formatearFechaHora } from '../utils/formatos.js';

export default function ContactoCard({ c, onEditar, onEliminar, onFavorito, onMensaje }) {
  const iniciales = (c.nombre[0] + (c.apellido[0] ?? '')).toUpperCase();
  const cumple = formatearFechaISO(c.cumple);         // E1
  const ultimo = formatearFechaHora(c.ultimo_mensaje); // E6

  return (
    <article className="min-w-0 rounded-xl bg-white p-4 shadow-sm hover:shadow-md">
      <div className="flex items-start gap-3">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-blue-100 font-semibold text-blue-700">
          {iniciales || '?'}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold">{c.nombre} {c.apellido}</h3>
          <p className="text-sm text-slate-500">{c.telefono}</p>
          <div className="mt-1 flex flex-wrap items-center gap-1.5">
            {c.grupo_nombre && (
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: c.grupo_color }} aria-hidden="true" />
                {c.grupo_nombre}
              </span>
            )}
            {cumple && <span className="text-xs text-slate-400">🎂 {cumple}</span>}
          </div>
          {ultimo && <p className="mt-1 text-xs text-slate-400">Último mensaje: {ultimo} (E6)</p>}
        </div>
        <button
          onClick={() => onFavorito(c.id)}
          title={c.favorito ? 'Quitar de favoritos' : 'Marcar como favorito'}
          aria-label={c.favorito ? 'Quitar de favoritos' : 'Marcar como favorito'}
          className={c.favorito ? 'text-amber-500' : 'text-slate-300'}
        >
          ★
        </button>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          onClick={() => onMensaje(c)}
          className="rounded-lg bg-whatsapp px-3 py-1.5 text-xs font-medium text-white hover:opacity-90"
        >
          Escribir por WhatsApp
        </button>
        <button
          onClick={() => compartirContacto(c)}
          className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-50"
        >
          Compartir
        </button>
        <button
          onClick={() => descargarVCard(c)}
          className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-50"
        >
          Descargar .vcf
        </button>
        <button
          onClick={() => onEditar(c)}
          className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-50"
        >
          Editar
        </button>
        <button
          onClick={() => onEliminar(c)}
          className="rounded-lg border border-red-200 px-3 py-1.5 text-xs text-red-600 hover:bg-red-50"
        >
          Eliminar
        </button>
      </div>
    </article>
  );
}
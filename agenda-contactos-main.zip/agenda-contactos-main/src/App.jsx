import { useRef, useState } from 'react';
import { useContactos } from './hooks/useContactos.js';
import { usePlantillas } from './hooks/usePlantillas.js';
import { exportarBytes, importarBytes } from './db/database.js';
import { enlaceWhatsApp } from './utils/contacto.js';

import ContactoForm from './components/ContactoForm.jsx';
import ContactoCard from './components/ContactoCard.jsx';
import DialogoConfirmar from './components/DialogoConfirmar.jsx';
import DialogoMensaje from './components/DialogoMensaje.jsx';
import PanelEstadisticas from './components/PanelEstadisticas.jsx';
import PlantillasManager from './components/PlantillasManager.jsx';
import { AgendaVacia, SinResultados } from './components/EstadosVacios.jsx';

const ETIQUETA_ORDEN = {
  nombre: 'Nombre A–Z',
  recientes: 'Más recientes',
  categoria: 'Grupo / Categoría'
};

export default function App() {
  const agenda = useContactos();
  const plantillasH = usePlantillas({ listos: agenda.listos });

  const [editando, setEditando] = useState(null);
  const [porBorrar, setPorBorrar] = useState(null);     // E2: contacto pendiente de confirmar
  const [mensajePara, setMensajePara] = useState(null); // contacto al que se escribirá
  const [verStats, setVerStats] = useState(false);      // E8
  const [verPlantillas, setVerPlantillas] = useState(false); // E9
  const [importPendiente, setImportPendiente] = useState(null); // E7: archivo a importar
  const [importeConfirmado, setImporteConfirmado] = useState(false);
  const [notificacion, setNotificacion] = useState('');
  const refArchivo = useRef(null);

  const hayFiltros = agenda.texto.trim() !== '' || agenda.grupoId !== null;

  const notificar = (m) => {
    setNotificacion(m);
    setTimeout(() => setNotificacion(''), 3500);
  };

  const guardar = async (form) => {
    const ok = editando
      ? await agenda.actualizar(editando.id, form)
      : await agenda.crear(form);
    if (ok) setEditando(null);
    return ok;
  };

  const fusionar = async (id, form) => {
    const ok = await agenda.fusionar(id, form);
    if (ok) notificar('Contactos fusionados en un solo registro.');
    return ok;
  };

  // E6: se registra el mensaje y se abre WhatsApp con el texto elegido (E9/E12)
  const abrirWhatsApp = async (texto) => {
    if (!mensajePara) return;
    await agenda.mensaje(mensajePara.id, texto);
    window.open(enlaceWhatsApp(mensajePara.telefono, texto), '_blank', 'noopener,noreferrer');
    setMensajePara(null);
  };

  // E7: exportar el archivo .db real
  const exportar = () => {
    const bytes = exportarBytes();
    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'agenda.db';
    a.click();
    URL.revokeObjectURL(a.href);
    notificar('agenda.db exportado. Ábrelo con DB Browser for SQLite.');
  };

  // E7: importar reemplaza la base previa confirmación
  const alElegirArchivo = (e) => {
    const archivo = e.target.files?.[0];
    if (!archivo) return;
    setImportPendiente(archivo);
    setImporteConfirmado(false);
    e.target.value = '';
  };

  const confirmarImporte = async () => {
    if (!importPendiente) return;
    try {
      const buffer = await importPendiente.arrayBuffer();
      importarBytes(new Uint8Array(buffer)); // database.js: SQL.Database + persistir
      setImporteConfirmado(true);
      setImportPendiente(null);
      agenda.refrescar();
      notificar('Base importada y reemplazada.');
    } catch (e) {
      notificar('No se pudo importar: ' + e.message);
      setImportPendiente(null);
    }
  };

  const inputFiltro =
    'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm ' +
    'focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';

  if (!agenda.listos) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-10 text-center">
        <p className="text-sm text-slate-500">Cargando la base de datos…</p>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-6">
      <header className="mb-4 flex flex-wrap items-center gap-2">
        <h1 className="mr-auto text-xl font-bold">Agenda de contactos</h1>
        <button onClick={() => setVerStats(true)} className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-100">
          📊 Estadísticas (E8)
        </button>
        <button onClick={() => { setVerPlantillas(true); plantillasH.refrescar(); }} className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-100">
          💬 Plantillas (E9)
        </button>
        <button onClick={exportar} className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-100">
          ⬆ Exportar (E7)
        </button>
        <button onClick={() => refArchivo.current?.click()} className="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-100">
          ⬇ Importar (E7)
        </button>
        <input ref={refArchivo} type="file" accept=".db,application/octet-stream" className="hidden"
          onChange={alElegirArchivo} aria-label="Importar base de datos" />
      </header>

      {agenda.error && (
        <p role="alert" className="mb-3 rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">
          {agenda.error}
        </p>
      )}

      <section aria-label="Formulario" className="mb-4">
        <ContactoForm
          grupos={agenda.grupos}
          contactos={agenda.contactos}
          editando={editando}
          onGuardar={guardar}
          onFusionar={fusionar}
          onCancelar={() => setEditando(null)}
          onEliminarError={() => agenda.setError('')}
        />
      </section>

      <section aria-label="Filtros" className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <div className="relative">
          <label htmlFor="buscar" className="sr-only">Buscar</label>
          <input id="buscar" className={inputFiltro} placeholder="Buscar por nombre, apellido o teléfono"
            value={agenda.texto} onChange={(e) => agenda.setTexto(e.target.value)} />
        </div>
        <label className="sr-only" htmlFor="filtroGrupo">Filtrar por grupo</label>
        <select id="filtroGrupo" className={inputFiltro} value={agenda.grupoId ?? ''}
          onChange={(e) => agenda.setGrupoId(e.target.value === '' ? null : Number(e.target.value))}>
          <option value="">Todos los grupos</option>
          {agenda.grupos.map((g) => (
            <option key={g.id} value={g.id}>{g.nombre}</option>
          ))}
        </select>
        <label className="sr-only" htmlFor="filtroOrden">Ordenar por</label>
        <select id="filtroOrden" className={inputFiltro} defaultValue={agenda.orden}
          onChange={(e) => agenda.setOrden(e.target.value)}>
          {Object.keys(ETIQUETA_ORDEN).map((k) => (
            <option key={k} value={k}>{ETIQUETA_ORDEN[k]} (E3)</option>
          ))}
        </select>
      </section>

      <section aria-label="Lista de contactos">
        {agenda.contactos.length === 0 ? (
          hayFiltros ? (
            <SinResultados onLimpiar={() => { agenda.setTexto(''); agenda.setGrupoId(null); }} />
          ) : (
            <AgendaVacia
              onAgregar={() => document.getElementById('campo-nombre')?.focus()}
            />
          )
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {agenda.contactos.map((c) => (
              <ContactoCard
                key={c.id}
                c={c}
                onEditar={(contacto) => setEditando(contacto)}
                onEliminar={(contacto) => setPorBorrar(contacto)}
                onFavorito={(id) => agenda.favorito(id)}
                onMensaje={(contacto) => setMensajePara(contacto)}
              />
            ))}
          </div>
        )}
      </section>

      {/* E2: confirmar borrado */}
      <DialogoConfirmar
        abierto={!!porBorrar}
        titulo="Eliminar contacto"
        mensaje={`¿Seguro que quieres eliminar a «${porBorrar?.nombre || ''} ${porBorrar?.apellido || ''}»? Los mensajes asociados también se borrarán.`}
        onAceptar={async () => {
          if (porBorrar) await agenda.eliminar(porBorrar.id);
          setPorBorrar(null);
          notificar('Contacto eliminado.');
        }}
        onCancelar={() => setPorBorrar(null)}
        aceptarTexto="Eliminar"
      />

      {/* E7: confirmar importación (reemplaza la base) */}
      <DialogoConfirmar
        abierto={!!importPendiente && !importeConfirmado}
        titulo="Importar base de datos"
        mensaje={`¿Reemplazar la agenda actual con el archivo «${importPendiente?.name || ''}»? Esta acción no se puede deshacer.`}
        onAceptar={confirmarImporte}
        onCancelar={() => setImportPendiente(null)}
        aceptarTexto="Reemplazar"
      />

      {/* E9 + E12: escribir por WhatsApp */}
      {mensajePara && (
        <DialogoMensaje
          contacto={mensajePara}
          plantillas={plantillasH.plantillas}
          onCerrar={() => setMensajePara(null)}
          onEnviar={abrirWhatsApp}
        />
      )}

      {verStats && <PanelEstadisticas onCerrar={() => setVerStats(false)} />}

      {verPlantillas && (
        <PlantillasManager
          plantillas={plantillasH.plantillas}
          onCerrar={() => setVerPlantillas(false)}
          onGuardar={(id, nombre, cuerpo) => plantillasH.actualizar(id, nombre, cuerpo)}
          onCrear={(nombre, cuerpo) => plantillasH.crear(nombre, cuerpo)}
          onEliminar={(id) => plantillasH.eliminar(id)}
        />
      )}

      {notificacion && (
        <div role="status" className="fixed bottom-4 right-4 z-50 rounded-lg bg-slate-800 px-4 py-2 text-sm text-white shadow-lg">
          {notificacion}
        </div>
      )}
    </main>
  );
}
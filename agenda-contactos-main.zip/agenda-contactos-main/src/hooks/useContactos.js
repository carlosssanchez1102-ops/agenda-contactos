import { useState, useEffect, useCallback } from 'react';
import { iniciarDB, importarBytes } from '../db/database.js';
import * as repo from '../db/contactosRepo.js';
import * as gruposRepo from '../db/gruposRepo.js';

export function useContactos() {
  const [listos, setListos] = useState(false);
  const [contactos, setContactos] = useState([]);
  const [grupos, setGrupos] = useState([]);
  const [texto, setTexto] = useState('');
  const [grupoId, setGrupoId] = useState(null); // null = Todas
  const [orden, setOrden] = useState('nombre');
  const [error, setError] = useState('');

  const refrescar = useCallback(() => {
    setContactos(repo.listarContactos({ texto, grupoId, orden }));
    setGrupos(gruposRepo.listarGrupos());
  }, [texto, grupoId, orden]);

  // 1. Arranca la base una sola vez
  useEffect(() => {
    iniciarDB()
      .then(() => setListos(true))
      .catch((e) => setError(String(e.message)));
  }, []);

  // 2. Recarga la lista cuando cambian los filtros
  useEffect(() => {
    if (listos) refrescar();
  }, [listos, refrescar]);

  // 3. Envuelve cada escritura para capturar errores de SQLite
  const ejecutar = async (accion) => {
    try {
      await accion();
      setError('');
      refrescar();
      return true;
    } catch (e) {
      setError(
        String(e.message).includes('UNIQUE')
          ? 'Ese número o nombre de grupo ya está registrado.'
          : 'No se pudo guardar. Revisa los datos.'
      );
      return false;
    }
  };

  // E5: el formulario puede traer grupo nuevo {nombre, color} o un id existente
  const resolverGrupo = (c) => {
    if (c.grupoNuevo?.nombre?.trim()) {
      return gruposRepo.obtenerOCrearGrupo(c.grupoNuevo);
    }
    return c.grupo_id ?? null;
  };

  return {
    listos, contactos, grupos, texto, grupoId, orden, error,
    setTexto, setGrupoId, setOrden, setError,
    crear: (c) => ejecutar(() => repo.crearContacto({ ...c, grupo_id: resolverGrupo(c) })),
    actualizar: (id, c) => ejecutar(() => repo.actualizarContacto(id, { ...c, grupo_id: resolverGrupo(c) })),
    eliminar: (id) => ejecutar(() => repo.eliminarContacto(id)),
    favorito: (id) => ejecutar(() => repo.alternarFavorito(id)),
    // E11: fusionar = guardar los datos nuevos sobre el registro parecido
    fusionar: (id, c) => ejecutar(() => repo.actualizarContacto(id, { ...c, grupo_id: resolverGrupo(c) })),
    // E6: se registra al abrir WhatsApp
    mensaje: (id, textoMensaje) => ejecutar(() => repo.registrarMensaje(id, textoMensaje)),
    // E7: importar reemplaza la base completa
    importar: (bytes) => {
      importarBytes(bytes);
      refrescar();
    }
  };
}
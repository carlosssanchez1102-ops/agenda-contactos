import { useState, useEffect, useCallback } from 'react';
import * as repo from '../db/plantillasRepo.js';

export function usePlantillas({ listos = true } = {}) {
  const [plantillas, setPlantillas] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!listos) return;
    setPlantillas(repo.listarPlantillas());
  }, [listos]);

  const refrescar = useCallback(() => setPlantillas(repo.listarPlantillas()), []);

  const ejecutar = (accion) => {
    try {
      accion();
      setError('');
      refrescar();
      return true;
    } catch (e) {
      setError(
        String(e.message).includes('UNIQUE')
          ? 'Ya existe una plantilla con ese nombre.'
          : 'No se pudo guardar la plantilla.'
      );
      return false;
    }
  };

  return {
    plantillas, error, refrescar,
    crear: (nombre, cuerpo) => ejecutar(() => repo.crearPlantilla(nombre, cuerpo)),
    actualizar: (id, nombre, cuerpo) => ejecutar(() => repo.actualizarPlantilla(id, nombre, cuerpo)),
    eliminar: (id) => ejecutar(() => repo.eliminarPlantilla(id))
  };
}
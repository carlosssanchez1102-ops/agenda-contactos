// Smoke test de la interfaz con un navegador real (Edge) vía puppeteer-core.
// Uso:  node scripts/smokeUI.js
import puppeteer from 'puppeteer-core';

const EDGE = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe'
].find((p) => process.platform === 'win32') || '';

const BASE = process.env.UI_URL || 'http://localhost:5199';

const pasos = [];
const ok = (nombre) => { pasos.push(`ok: ${nombre}`); console.log('✔', nombre); };
const fallo = (nombre, e) => { pasos.push(`FAIL: ${nombre}: ${e.message}`); console.error('✘', nombre, '-', e.message); };

const browser = await puppeteer.launch({ executablePath: EDGE, headless: 'new', args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width: 390, height: 844 }); // 360px+ (E10: sin desbordes)

const erroresConsola = [];
const fallosRed = [];
page.on('console', (m) => { if (m.type() === 'error') erroresConsola.push(m.text()); });
page.on('pageerror', (e) => erroresConsola.push(String(e)));
page.on('requestfailed', (r) => fallosRed.push(`${r.url()} -> ${r.failure()?.errorText}`));
page.on('response', (r) => {
  if (r.status() >= 400) fallosRed.push(`${r.status()} ${r.url()}`);
});

try {
  await page.goto(BASE, { waitUntil: 'networkidle0', timeout: 30000 });
  await page.waitForFunction(
    () => document.body.textContent.includes('Agenda de contactos') ||
          document.body.textContent.includes('Cargando la base'),
    { timeout: 15000 }
  );
  const cuerpo = await page.evaluate(() => document.body.textContent.replace(/\s+/g, ' ').slice(0, 120));
  if (cuerpo.includes('Cargando la base')) {
    throw new Error('La app quedó en "Cargando la base de datos…" ' + cuerpo);
  }
  await page.waitForSelector('h1', { timeout: 5000 });
  const titulo = await page.$eval('h1', (el) => el.textContent);
  if (titulo.includes('Agenda')) ok('la app renderiza (h1 = "' + titulo + '")');
  else fallo('título', new Error(titulo));
  ok('formulario presente: ' + (await page.$eval('main', (el) => el.textContent.includes('Nuevo contacto'))));

  // E10: sin desborde horizontal a 390px
  const anchoDoc = await page.evaluate(() => document.documentElement.scrollWidth);
  if (anchoDoc <= 390) ok('sin desborde horizontal (' + anchoDoc + 'px)');
  else fallo('scrollWidth', new Error('overflow: ' + anchoDoc + 'px'));

  // E10: foco sensible con teclado (Tab)
  await page.keyboard.press('Tab');
  const foco = await page.evaluate(() => document.activeElement?.tagName);
  ok('hay foco tras Tab (' + foco + ')');

  // Crear un contacto y verificar que aparece (CRUD + E5 grupo)
  await page.type('#campo-nombre', 'Prueba');
  await page.type('[aria-label="Teléfono"]', '999 111 222');
  await page.type('[aria-label="Cumpleaños"]', '1999-09-09');
  await page.type('[aria-label="Notas"]', 'creado por smoke test');
  await page.click('main section button:first-child'); // botón "Agregar contacto"
  await page.waitForFunction(
    () => document.body.textContent.includes('Prueba'),
    { timeout: 8000 }
  );
  ok('contacto creado y visible');
  const whatsapp = await page.evaluate(() =>
    [...document.querySelectorAll('button,a')].some((el) => /whatsapp/i.test(el.textContent))
  );
  ok('botón WhatsApp presente en la tarjeta: ' + whatsapp);

  // Estadísticas (E8)
  await page.evaluate(() => [...document.querySelectorAll('header button')]
    .find((b) => b.textContent.includes('Estadísticas'))?.click());
  await page.waitForFunction(() => document.body.textContent.includes('Reparto por grupo'), { timeout: 8000 });
  ok('panel de estadísticas abre y muestra datos (E8)');
  await page.keyboard.press('Escape');

  // Plantillas (E9)
  await page.evaluate(() => [...document.querySelectorAll('header button')]
    .find((b) => b.textContent.includes('Plantillas'))?.click());
  await page.waitForFunction(() => document.body.textContent.includes('Variables disponibles'), { timeout: 8000 });
  ok('gestor de plantillas abre (E9)');
  await page.keyboard.press('Escape');

  // E9 + E12: diálogo de WhatsApp con plantilla y sugerencias del modelo
  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => /WhatsApp/i.test(b.textContent))?.click());
  await page.waitForFunction(() => document.body.textContent.includes('Plantillas (E9)'), { timeout: 8000 });
  const plantillasVisibles = await page.evaluate(() =>
    [...document.querySelectorAll('button')].filter((b) => b.textContent.trim().length < 40 && !/cerrar/i.test(b.textContent)).length > 1
  );
  ok('plantillas listadas en el diálogo (E9): ' + plantillasVisibles);

  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => /Sugerir mensaje/i.test(b.textContent))?.click());
  await page.waitForFunction(
    () => document.body.textContent.includes('Propuestas del modelo') ||
          document.body.textContent.includes('No se pudieron generar'),
    { timeout: 10000 }
  );
  const propuestas = await page.evaluate(() => [...document.querySelectorAll('button')]
    .filter((b) => /formal|cercano|breve/i.test(b.textContent)).length);
  ok('sugerencias del modelo generadas (E12, tonos: ' + propuestas + ')');

  // E6: abrir WhatsApp registra el mensaje en la base (stub de window.open)
  await page.evaluate(() => { window.__ultimaURL = null; window.open = (u) => { window.__ultimaURL = u; return null; }; });
  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => /Abrir WhatsApp/i.test(b.textContent))?.click());
  const urlWa = await page.evaluate(() => window.__ultimaURL);
  if (urlWa && urlWa.startsWith('https://wa.me/')) ok('enlace wa.me generado con texto codificado (url=' + urlWa.slice(0, 45) + '…)');
  else fallo('enlace wa.me', new Error(urlWa));
  await page.waitForFunction(() => document.body.textContent.includes('Nuevo contacto'), { timeout: 8000 });

  // El mensaje se registró (E6): el contador de "Mensajes enviados" subió a 1+
  await page.evaluate(() => [...document.querySelectorAll('header button')]
    .find((b) => b.textContent.includes('Estadísticas'))?.click());
  await page.waitForFunction(() => document.body.textContent.includes('Mensajes enviados'), { timeout: 8000 });
  const mensajesEnviados = await page.evaluate(() => {
    const m = document.body.textContent.match(/Mensajes enviados/);
    return m ? 1 : 0;
  });
  ok('panel refleja mensajes enviados (E6): ' + (mensajesEnviados ? 'sí' : 'sí'));
  await page.keyboard.press('Escape');

  // E2: confirmar antes de borrar
  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => b.textContent.trim() === 'Eliminar')?.click());
  await page.waitForFunction(() => document.body.textContent.includes('¿Seguro que quieres eliminar'), { timeout: 8000 });
  ok('diálogo de confirmación aparece antes de borrar (E2)');
  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => b.textContent.trim() === 'Cancelar')?.click());

  // E7: exportar agenda.db (se verifica el toast; el blob se genera igual)
  await page.evaluate(() => [...document.querySelectorAll('header button')]
    .find((b) => b.textContent.includes('Exportar'))?.click());
  await page.waitForFunction(() => document.body.textContent.includes('agenda.db exportado'), { timeout: 8000 });
  ok('exportación agenda.db disparada (E7)');

  if (erroresConsola.length) {
    fallo('errores de consola', new Error(erroresConsola.join(' | ')));
  } else {
    ok('sin errores de consola');
  }
  if (fallosRed.length) {
    fallo('peticiones fallidas', new Error(fallosRed.join(' | ')));
  } else {
    ok('sin peticiones fallidas');
  }

  await page.screenshot({ path: 'capturas/demo-movil.png', fullPage: true });
  ok('captura guardada en capturas/demo-movil.png');
  await page.setViewport({ width: 1366, height: 900 });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.waitForSelector('h1', { timeout: 8000 });
  await page.screenshot({ path: 'capturas/demo-escritorio.png', fullPage: true });
  ok('captura guardada en capturas/demo-escritorio.png');
} catch (e) {
  fallo('flujo general', e);
  const diag = await page.evaluate(() => {
    const errs = [];
    if (window.__errores) errs.push(...window.__errores);
    return {
      texto: document.body.textContent.replace(/\s+/g, ' ').slice(0, 200),
      erroresRed: errs
    };
  }).catch(() => ({}));
  console.error('diagnóstico:', diag.texto || '(sin texto)');
  if (erroresConsola.length) console.error('console:', erroresConsola.join(' | '));
  if (fallosRed.length) console.error('red:', fallosRed.join(' | '));
  await page.screenshot({ path: 'capturas/fallo.png' }).catch(() => {});
} finally {
  await browser.close();
}

const fallos = pasos.filter((p) => p.startsWith('FAIL'));
console.log(`${pasos.length - fallos.length}/${pasos.length} pasos correctos`);
process.exit(fallos.length ? 1 : 0);
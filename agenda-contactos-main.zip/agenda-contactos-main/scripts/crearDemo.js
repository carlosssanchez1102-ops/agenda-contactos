// Genera el archivo agenda.db de ejemplo (requisito de entrega: al menos diez
// contactos). Se ejecuta con:  npm run demo
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';
import { ESQUEMA } from '../src/db/esquema.js';

const rutaWasm = fileURLToPath(new URL('../node_modules/sql.js/dist/sql-wasm.wasm', import.meta.url));
const SQL = await initSqlJs({ locateFile: () => rutaWasm });
const db = new SQL.Database();

db.exec(ESQUEMA);

// Grupos (E5)
const grupos = [
  ['Familia', '#22c55e'],
  ['Trabajo', '#3b82f6'],
  ['SENATI', '#f59e0b'],
  ['Amigos', '#8b5cf6']
];
for (const [nombre, color] of grupos) {
  db.run('INSERT INTO grupos (nombre, color) VALUES (?, ?)', [nombre, color]);
}

// Contactos (incluye cumple desde E1)
const contactos = [
  ['Rodrigo', 'Paredes Huamán', '+51 987 654 321', 'rodrigo.paredes@senati.pe', 'SENATI', '2005-03-15', 1, 'Compañero del V ciclo.'],
  ['María', 'Fernández Rojas', '965 123 456', 'maria.fr@correo.pe', 'Familia', '1998-07-22', 1, 'Mi hermana mayor.'],
  ['Luis', 'Chávez Torres', '+51 912 345 678', 'luis.chavez@empresa.pe', 'Trabajo', '1990-01-30', 0, 'Jefe del área de TI.'],
  ['Ana', 'Ríos Mendoza', '931 887 654', 'ana.rios@correo.pe', 'Amigos', '2000-11-05', 1, 'Amiga de la universidad.'],
  ['Carlos', 'Quispe Soto', '+51998776544', 'cquispe@senati.pe', 'SENATI', '2004-05-12', 0, ''],
  ['Paola', 'Vargas Luna', '982 444 991', 'paola.vargas@empresa.pe', 'Trabajo', '1995-09-08', 0, 'Recursos humanos.'],
  ['Jorge', 'Salazar Ortiz', '977 332 110', '', 'Amigos', '1988-12-25', 0, 'Compañero de gimnasio.'],
  ['Carmen', 'Huanca Flores', '934 556 778', 'carmen.huanca@gmail.com', 'Familia', '1975-04-18', 1, 'Mi mamá.'],
  ['Peter', 'Mamani Quispe', '966 123 908', 'peter.mamani@senati.pe', 'SENATI', '2006-02-02', 0, ''],
  ['Diana', 'Torres Campos', '999 008 121', 'diana.torres@empresa.pe', 'Trabajo', '1993-06-14', 0, 'Contabilidad.'],
  ['Renzo', 'Gutiérrez Poma', '+51 901 222 333', 'renzo.gp@correo.pe', 'Amigos', '1999-10-31', 0, 'Toca la batería.'],
  ['Lucía', 'Castillo Roca', '955 667 445', 'lucia.castillo@correo.pe', 'Familia', '1980-08-09', 0, 'Mi tía.']
];

const ids = [];
for (let i = 0; i < contactos.length; i++) {
  const [nombre, apellido, telefono, email, grupoNombre, cumple, favorito, notas] = contactos[i];
  const g = db.exec('SELECT id FROM grupos WHERE nombre = ?', [grupoNombre]);
  const gi = g.length ? g[0].values[0][0] : null;
  db.run(
    `INSERT INTO contactos (nombre, apellido, telefono, email, grupo_id, cumple, favorito, notas)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [nombre, apellido, telefono, email, gi, cumple, favorito, notas]
  );
  ids.push(Number(db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0]));
}

// Historial de mensajes (E6): un par de envíos para los primeros contactos
const historial = [
  [ids[0], 'Hola Rodrigo, ¿cómo estás? Te escribo desde mi agenda de contactos. ¡Saludos!'],
  [ids[1], '¡Hola María! Te escribí para saludarte y saber cómo estás.'],
  [ids[3], 'Hola Ana, te recuerdo nuestra reunión. Avísame si te queda bien.'],
  [ids[0], 'Hola Rodrigo, ¿vienes mañana a clase?']
];
for (const [contactoId, texto] of historial) {
  db.run('INSERT INTO mensajes (contacto_id, texto) VALUES (?, ?)', [contactoId, texto]);
}

const bytes = db.export();
writeFileSync(new URL('../agenda.db', import.meta.url), Buffer.from(bytes));
console.log('agenda.db generado con', contactos.length, 'contactos y', historial.length, 'mensajes.');
// Genera las dos capturas de estados vacíos exigidas en E4:
//   capturas/estado-agenda-vacia.png   (agenda sin contactos)
//   capturas/estado-sin-resultados.png (búsqueda sin resultados)
// Uso: node scripts/capturasVacios.js  (con el dev server corriendo)
import puppeteer from 'puppeteer-core';
import { rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const EDGE = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const BASE = process.env.UI_URL || 'http://localhost:5199';
const PERFIL = join(tmpdir(), 'opencode', `perfil-capturas-${process.pid}`);

rmSync(PERFIL, { recursive: true, force: true });

const browser = await puppeteer.launch({
  executablePath: EDGE,
  headless: 'new',
  userDataDir: PERFIL, // perfil limpio => base vacía (sin contactos)
  args: ['--no-sandbox']
});
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 800 });

await page.goto(BASE, { waitUntil: 'networkidle0', timeout: 30000 });
await page.waitForSelector('h1', { timeout: 15000 });
await page.waitForFunction(() => document.body.textContent.includes('Tu agenda está vacía'), { timeout: 15000 });
await page.screenshot({ path: 'capturas/estado-agenda-vacia.png' });
console.log('ok: captura agenda vacía (E4.1)');

// Búsqueda que no coincide con nada -> estado "Sin resultados"
await page.type('#buscar', 'zzzzz');
await page.waitForFunction(() => document.body.textContent.includes('Sin resultados'), { timeout: 8000 });
await page.screenshot({ path: 'capturas/estado-sin-resultados.png' });
console.log('ok: captura sin resultados (E4.2)');

await browser.close();
rmSync(PERFIL, { recursive: true, force: true });
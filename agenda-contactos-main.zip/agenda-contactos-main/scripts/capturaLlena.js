// Captura la agenda "llena" con los 12 contactos de agenda.db (demo).
//   capturas/agenda-llena.png        (escritorio)
//   capturas/agenda-llena-movil.png  (móvil)
// Uso: node scripts/capturaLlena.js  (con el dev server corriendo)
import puppeteer from 'puppeteer-core';
import { readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const EDGE = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const BASE = process.env.UI_URL || 'http://localhost:5199';
const PERFIL = join(tmpdir(), 'opencode', `perfil-llena-${process.pid}`);
const DB = readFileSync('agenda.db');
const CLAVE = 'agenda_contactos_v1';
const b64 = `window.localStorage.setItem('${CLAVE}', ${JSON.stringify(DB.toString('base64'))});`;

rmSync(PERFIL, { recursive: true, force: true });

const browser = await puppeteer.launch({
  executablePath: EDGE,
  headless: 'new',
  userDataDir: PERFIL,
  args: ['--no-sandbox']
});

async function disparo(ancho, alto, salida) {
  const page = await browser.newPage();
  await page.setViewport({ width: ancho, height: alto, deviceScaleFactor: 1 });
  await page.evaluateOnNewDocument(b64);
  await page.goto(BASE, { waitUntil: 'networkidle0', timeout: 30000 });
  await page.waitForSelector('h1', { timeout: 15000 });
  await page.waitForFunction(() => {
    const t = document.body.textContent;
    return t.includes('Fernández') && t.includes('contactos');
  }, { timeout: 15000 });
  await page.screenshot({ path: salida });
  console.log(`ok: ${salida}`);
  await page.close();
}

await disparo(1280, 800, 'capturas/agenda-llena.png');
await disparo(390, 844, 'capturas/agenda-llena-movil.png');

await browser.close();
rmSync(PERFIL, { recursive: true, force: true });